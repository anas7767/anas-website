import { useEffect, useRef } from 'react'

export default function WhyMe() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = sectionRef.current
    if (!el) return
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.opacity = '1'
          el.style.transform = 'translateY(0)'
          obs.unobserve(el)
        }
      },
      { threshold: 0.12 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])

  return (
    <section
      id="about"
      ref={sectionRef}
      style={{
        padding: '130px 0',
        opacity: 0,
        transform: 'translateY(28px)',
        transition: 'opacity 650ms ease-out, transform 650ms ease-out',
      }}
    >
      <div style={{ maxWidth: '1080px', margin: 'auto', padding: '0 clamp(28px, 6vw, 80px)' }}>
        <div style={{ fontFamily: "'Inter', sans-serif", fontSize: '11px', fontWeight: 600, letterSpacing: '0.2em', color: '#F59E0B', textTransform: 'uppercase', marginBottom: '16px' }}>
          WHY ME
        </div>
        <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: '50px', fontWeight: 800, color: '#0A0A0A', marginBottom: '48px', marginTop: 0 }}>
          The Right Person.
        </h2>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '48px' }}>
          <div style={{ flex: '65 1 300px', fontFamily: "'Inter', sans-serif", fontSize: '17px', color: '#374151', lineHeight: 1.88 }}>
            <p style={{ marginBottom: '24px', marginTop: 0 }}>
              Most founders building for kiranas found the problem in a market report.
            </p>
            <p style={{ marginBottom: '24px', marginTop: 0, fontFamily: "'Syne', sans-serif", fontSize: '20px', fontWeight: 700, color: '#0A0A0A' }}>
              I found it by being inside it.
            </p>
            <p style={{ marginBottom: '24px', marginTop: 0 }}>
              I understand how informal credit moves — not as a concept, but as a mechanism. I know what breaks it, what replaces it, and what a kirana owner actually needs versus what the market assumes he needs.
            </p>
            <p style={{ marginBottom: 0, marginTop: 0 }}>
              The Feri Exchange Model didn't come from research. It came from seeing both sides of the same problem and being the first to connect them. That's not something you learn. That's something you're positioned for.
            </p>
          </div>
          <div style={{ flex: '35 1 200px', display: 'flex', flexDirection: 'column', gap: '28px' }}>
            {[
              { num: '17', label: 'Building from where most founders never look' },
              { num: 'India', label: 'Where the problem actually lives' },
              { num: 'YC', label: 'Y Combinator applicant' },
            ].map((card) => (
              <div key={card.num} style={{ borderLeft: '3px solid #F59E0B', paddingLeft: '20px', paddingTop: '16px', paddingBottom: '16px' }}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontSize: '44px', fontWeight: 800, color: '#0A0A0A' }}>{card.num}</div>
                <div style={{ fontFamily: "'Inter', sans-serif", fontSize: '13px', color: '#6B7280', marginTop: '4px' }}>{card.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
