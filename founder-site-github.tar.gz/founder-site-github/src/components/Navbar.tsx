export default function Navbar() {
  const scrollTo = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault()
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <nav
      style={{
        position: 'sticky',
        top: 0,
        height: '60px',
        backgroundColor: 'rgba(255,255,255,0.82)',
        backdropFilter: 'blur(18px)',
        borderBottom: '1px solid #E5E7EB',
        zIndex: 100,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 28px',
      }}
    >
      <div style={{ fontFamily: "'Syne', sans-serif", fontSize: '15px', fontWeight: 700, color: '#0A0A0A' }}>
        Anas Shaikh
      </div>
      <div style={{ display: 'flex', gap: '24px' }}>
        {[
          { label: 'About', id: 'about' },
          { label: 'Feri', id: 'feri' },
          { label: 'Contact', id: 'contact' },
        ].map((link) => (
          <a
            key={link.id}
            href={`#${link.id}`}
            onClick={scrollTo(link.id)}
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '13px',
              fontWeight: 500,
              color: '#6B7280',
              textDecoration: 'none',
              transition: 'color 150ms',
            }}
            onMouseEnter={(e) => { e.currentTarget.style.color = '#0A0A0A' }}
            onMouseLeave={(e) => { e.currentTarget.style.color = '#6B7280' }}
          >
            {link.label}
          </a>
        ))}
      </div>
    </nav>
  )
}
