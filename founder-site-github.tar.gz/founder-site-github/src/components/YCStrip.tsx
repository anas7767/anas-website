import { useEffect, useRef } from 'react'

export default function YCStrip() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = sectionRef.current
    if (!el) return
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.opacity = '1'
          el.style.transform = 'translateY(0)'
          obs.unobserve(el)
        }
      },
      { threshold: 0.12 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      style={{
        backgroundColor: '#F59E0B',
        padding: '72px 0',
        textAlign: 'center',
        opacity: 0,
        transform: 'translateY(28px)',
        transition: 'opacity 650ms ease-out, transform 650ms ease-out',
      }}
    >
      <div style={{ maxWidth: '1080px', margin: 'auto', padding: '0 clamp(28px, 6vw, 80px)' }}>
        <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 'clamp(32px, 5vw, 46px)', fontWeight: 800, color: '#0A0A0A', margin: 0 }}>
          Applying to Y Combinator.
        </h2>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: '18px', fontWeight: 500, color: '#78350F', marginTop: '14px', marginBottom: 0 }}>
          Not to validate the idea — the idea is already working. To build faster.
        </p>
      </div>
    </section>
  )
}
