import { useEffect, useRef } from 'react'

export default function Insight() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = sectionRef.current
    if (!el) return
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.opacity = '1'
          el.style.transform = 'translateY(0)'
          obs.unobserve(el)
        }
      },
      { threshold: 0.12 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])

  return (
    <section
      id="insight"
      ref={sectionRef}
      style={{
        backgroundColor: '#0A0A0A',
        padding: '130px 0',
        color: 'white',
        opacity: 0,
        transform: 'translateY(28px)',
        transition: 'opacity 650ms ease-out, transform 650ms ease-out',
      }}
    >
      <div style={{ maxWidth: '880px', margin: 'auto', padding: '0 clamp(28px, 6vw, 80px)', textAlign: 'center' }}>
        <div style={{ fontFamily: "'Inter', sans-serif", fontSize: '11px', fontWeight: 600, letterSpacing: '0.2em', color: '#F59E0B', textTransform: 'uppercase', marginBottom: '24px' }}>
          THE INSIGHT
        </div>
        <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 'clamp(38px, 5vw, 58px)', fontWeight: 800, lineHeight: 1.2, marginBottom: '56px', marginTop: 0, whiteSpace: 'pre-line' }}>
          {'One problem.\nTwo sides.\nNobody connected them.'}
        </h2>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', textAlign: 'left' }}>
          <div style={{ flex: '1 1 300px', backgroundColor: 'white', borderRadius: '16px', padding: '36px' }}>
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: '11px', fontWeight: 600, letterSpacing: '0.18em', color: '#F59E0B', textTransform: 'uppercase' }}>THE D2C SIDE</div>
            <h3 style={{ fontFamily: "'Syne', sans-serif", fontSize: '26px', fontWeight: 700, color: '#0A0A0A', marginTop: '10px', marginBottom: 0 }}>Overstock</h3>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: '15px', color: '#4B5563', lineHeight: 1.7, marginTop: '12px', marginBottom: 0 }}>
              D2C brands overorder. Inventory piles up. Returns are expensive and damage margins. Dead stock with nowhere to go.
            </p>
          </div>
          <div style={{ flex: '1 1 300px', backgroundColor: '#F59E0B', borderRadius: '16px', padding: '36px' }}>
            <div style={{ fontFamily: "'Inter', sans-serif", fontSize: '11px', fontWeight: 600, letterSpacing: '0.18em', color: '#78350F', textTransform: 'uppercase' }}>THE KIRANA SIDE</div>
            <h3 style={{ fontFamily: "'Syne', sans-serif", fontSize: '26px', fontWeight: 700, color: '#0A0A0A', marginTop: '10px', marginBottom: 0 }}>Understock</h3>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: '15px', color: '#1C1917', lineHeight: 1.7, marginTop: '12px', marginBottom: 0 }}>
              Kiranas run short. Informal credit is expensive and unreliable. They can't access inventory when they need it most.
            </p>
          </div>
        </div>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: '19px', fontWeight: 500, lineHeight: 1.6, marginTop: '48px', marginBottom: 0, fontStyle: 'italic', color: 'white' }}>
          "One side's liability is the other side's asset. Feri built the connection."
        </p>
      </div>
    </section>
  )
}
