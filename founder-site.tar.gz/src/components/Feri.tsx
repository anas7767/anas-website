import { useEffect, useRef } from 'react';

export default function Feri() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.opacity = '1';
          el.style.transform = 'translateY(0)';
          obs.unobserve(el);
        }
      },
      { threshold: 0.12 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <section
      id="feri"
      ref={sectionRef}
      style={{
        backgroundColor: '#FAFAFA',
        padding: '130px 0',
        opacity: 0,
        transform: 'translateY(28px)',
        transition: 'opacity 650ms ease-out, transform 650ms ease-out',
      }}
    >
      <div
        style={{
          maxWidth: '1080px',
          margin: 'auto',
          padding: '0 clamp(28px, 6vw, 80px)',
        }}
      >
        <div
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '11px',
            fontWeight: 600,
            letterSpacing: '0.2em',
            color: '#F59E0B',
            textTransform: 'uppercase',
            marginBottom: '16px',
          }}
        >
          THE COMPANY
        </div>
        <h2
          style={{
            fontFamily: "'Syne', sans-serif",
            fontSize: '50px',
            fontWeight: 800,
            color: '#0A0A0A',
            margin: 0,
          }}
        >
          Feri
        </h2>
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '20px',
            fontWeight: 400,
            color: '#6B7280',
            maxWidth: '520px',
            lineHeight: 1.65,
            marginTop: '14px',
            marginBottom: '64px',
          }}
        >
          B2B commerce and credit infrastructure for India's kirana stores.
        </p>

        <div className="flex flex-col md:flex-row gap-16">
          <div className="flex-1">
            <h3
              style={{
                fontFamily: "'Syne', sans-serif",
                fontSize: '22px',
                fontWeight: 700,
                color: '#0A0A0A',
                marginBottom: '24px',
                marginTop: 0,
              }}
            >
              How it works
            </h3>
            <div className="flex flex-col gap-5">
              {[
                { num: '01', text: 'Kiranas order inventory through Feri.' },
                { num: '02', text: 'NBFC-backed credit flows automatically. No collateral. No delays.' },
                { num: '03', text: 'The Exchange Model routes unsold D2C inventory as kirana supply credit — not a return shipment.' },
              ].map((step, i) => (
                <div key={i} className="flex gap-4">
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '12px',
                      fontWeight: 600,
                      color: '#F59E0B',
                      marginTop: '4px',
                    }}
                  >
                    {step.num}
                  </div>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '16px',
                      color: '#374151',
                      lineHeight: 1.7,
                    }}
                  >
                    {step.text}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex-1">
            <div
              style={{
                backgroundColor: '#0A0A0A',
                borderRadius: '16px',
                padding: '36px',
              }}
            >
              <h3
                style={{
                  fontFamily: "'Syne', sans-serif",
                  fontSize: '22px',
                  fontWeight: 700,
                  color: 'white',
                  marginBottom: '16px',
                  marginTop: 0,
                }}
              >
                The Exchange Model
              </h3>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: '16px',
                  color: '#9CA3AF',
                  lineHeight: 1.8,
                  margin: 0,
                }}
              >
                Unsold D2C stock doesn't go back to the brand. It becomes credit at the kirana. One transaction. Two problems solved. Nobody loses.
              </p>
              <div
                style={{
                  width: '40px',
                  height: '3px',
                  backgroundColor: '#F59E0B',
                  borderRadius: '2px',
                  marginTop: '24px',
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
