import { useEffect, useState } from 'react';

export default function Hero() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    setShow(true);
  }, []);

  const scrollTo = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const getStyle = (delay: number) => ({
    opacity: show ? 1 : 0,
    transform: show ? 'translateY(0)' : 'translateY(20px)',
    transition: `opacity 550ms ease-out ${delay}ms, transform 550ms ease-out ${delay}ms`,
  });

  return (
    <section
      style={{
        height: 'calc(100vh - 60px)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        paddingLeft: 'clamp(28px, 8vw, 128px)',
        paddingRight: '28px',
        maxWidth: '700px',
      }}
    >
      <div
        style={{
          ...getStyle(0),
          fontFamily: "'Inter', sans-serif",
          fontSize: '11px',
          fontWeight: 600,
          letterSpacing: '0.2em',
          color: '#F59E0B',
          textTransform: 'uppercase',
          marginBottom: '16px',
        }}
      >
        FOUNDER & CEO — FERI
      </div>
      <div
        style={{
          ...getStyle(0),
          fontFamily: "'Syne', sans-serif",
          fontSize: 'clamp(13px, 1.5vw, 16px)',
          fontWeight: 600,
          color: '#0A0A0A',
          letterSpacing: '0.04em',
          marginTop: '10px',
          marginBottom: '4px',
          opacity: show ? 0.5 : 0,
        }}
      >
        India's Retail Supply Engine
      </div>
      <h1
        style={{
          ...getStyle(80),
          fontFamily: "'Syne', sans-serif",
          fontSize: 'clamp(54px, 7.5vw, 90px)',
          fontWeight: 800,
          color: '#0A0A0A',
          lineHeight: 1.04,
          margin: 0,
        }}
      >
        Anas Shaikh
      </h1>
      <p
        style={{
          ...getStyle(190),
          fontFamily: "'Inter', sans-serif",
          fontSize: '18px',
          fontWeight: 400,
          color: '#6B7280',
          lineHeight: 1.75,
          maxWidth: '520px',
          marginTop: '24px',
          marginBottom: '0',
        }}
      >
        I'm building the supply and credit infrastructure that India's kirana economy has never had. I'm not guessing at the problem. I know it.
      </p>
      <div
        style={{
          ...getStyle(320),
          marginTop: '40px',
          display: 'flex',
          gap: '14px',
          flexWrap: 'wrap',
        }}
      >
        <button
          onClick={scrollTo('feri')}
          style={{
            backgroundColor: '#0A0A0A',
            color: 'white',
            padding: '11px 26px',
            borderRadius: '9999px',
            fontFamily: "'Inter', sans-serif",
            fontSize: '14px',
            fontWeight: 600,
            border: 'none',
            cursor: 'pointer',
            transition: 'opacity 200ms, transform 200ms',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.opacity = '0.85';
            e.currentTarget.style.transform = 'scale(1.02)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.opacity = '1';
            e.currentTarget.style.transform = 'scale(1)';
          }}
        >
          Explore Feri &rarr;
        </button>
        <button
          onClick={scrollTo('contact')}
          style={{
            backgroundColor: 'transparent',
            color: '#0A0A0A',
            padding: '11px 26px',
            borderRadius: '9999px',
            fontFamily: "'Inter', sans-serif",
            fontSize: '14px',
            fontWeight: 600,
            border: '1.5px solid #0A0A0A',
            cursor: 'pointer',
            transition: 'background-color 200ms, color 200ms',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = '#0A0A0A';
            e.currentTarget.style.color = 'white';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'transparent';
            e.currentTarget.style.color = '#0A0A0A';
          }}
        >
          Get in Touch
        </button>
      </div>
    </section>
  );
}
