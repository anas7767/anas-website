import { useEffect, useRef } from 'react';

export default function Contact() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.opacity = '1';
          el.style.transform = 'translateY(0)';
          obs.unobserve(el);
        }
      },
      { threshold: 0.12 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <section
      id="contact"
      ref={sectionRef}
      style={{
        padding: '130px 0',
        opacity: 0,
        transform: 'translateY(28px)',
        transition: 'opacity 650ms ease-out, transform 650ms ease-out',
      }}
    >
      <div
        style={{
          maxWidth: '600px',
          margin: 'auto',
          textAlign: 'center',
          padding: '0 clamp(28px, 6vw, 80px)',
        }}
      >
        <h2
          style={{
            fontFamily: "'Syne', sans-serif",
            fontSize: '50px',
            fontWeight: 800,
            color: '#0A0A0A',
            margin: 0,
          }}
        >
          Let's Talk.
        </h2>
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '17px',
            color: '#6B7280',
            lineHeight: 1.75,
            maxWidth: '440px',
            margin: '18px auto 0 auto',
          }}
        >
          If you're thinking about kirana infrastructure, informal trade credit, or building in India — I'd like to talk.
        </p>
        <div style={{ marginTop: '40px' }}>
          <a
            href="mailto:anas983shaikh@gmail.com"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '17px',
              fontWeight: 600,
              color: '#0A0A0A',
              textDecoration: 'none',
              transition: 'text-decoration 150ms',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.textDecoration = 'underline';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.textDecoration = 'none';
            }}
          >
            anas983shaikh@gmail.com
          </a>
        </div>
      </div>
    </section>
  );
}
