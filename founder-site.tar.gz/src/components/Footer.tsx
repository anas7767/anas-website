export default function Footer() {
  return (
    <footer
      style={{
        borderTop: '1px solid #E5E7EB',
        padding: '28px 0',
        textAlign: 'center',
      }}
    >
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: '13px',
          color: '#9CA3AF',
        }}
      >
        © 2026 Anas Shaikh
      </div>
    </footer>
  );
}
