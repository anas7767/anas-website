export default function DotBackground() {
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      zIndex: 0,
      pointerEvents: 'none',
      backgroundImage: 'radial-gradient(circle, rgba(0,0,0,0.13) 1.5px, transparent 1.5px)',
      backgroundSize: '28px 28px',
      animation: 'dotDrift 10s linear infinite',
    }} />
  );
}
