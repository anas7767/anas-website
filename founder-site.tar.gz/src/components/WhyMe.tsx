import { useEffect, useRef } from 'react';

export default function WhyMe() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.opacity = '1';
          el.style.transform = 'translateY(0)';
          obs.unobserve(el);
        }
      },
      { threshold: 0.12 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      style={{
        padding: '130px 0',
        opacity: 0,
        transform: 'translateY(28px)',
        transition: 'opacity 650ms ease-out, transform 650ms ease-out',
      }}
    >
      <div
        style={{
          maxWidth: '1080px',
          margin: 'auto',
          padding: '0 clamp(28px, 6vw, 80px)',
        }}
      >
        <div
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: '11px',
            fontWeight: 600,
            letterSpacing: '0.2em',
            color: '#F59E0B',
            textTransform: 'uppercase',
            marginBottom: '16px',
          }}
        >
          WHY ME
        </div>
        <h2
          style={{
            fontFamily: "'Syne', sans-serif",
            fontSize: '50px',
            fontWeight: 800,
            color: '#0A0A0A',
            marginBottom: '48px',
            marginTop: 0,
          }}
        >
          The Right Person.
        </h2>

        <div className="flex flex-col md:flex-row gap-12 md:gap-24">
          <div
            className="md:w-[65%]"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: '17px',
              color: '#374151',
              lineHeight: 1.88,
            }}
          >
            <p className="mb-6">
              Most founders building for kiranas found the problem in a market report.
            </p>
            <p
              className="mb-6"
              style={{
                fontFamily: "'Syne', sans-serif",
                fontSize: '20px',
                fontWeight: 700,
                color: '#0A0A0A',
              }}
            >
              I found it by being inside it.
            </p>
            <p className="mb-6">
              I understand how informal credit moves — not as a concept, but as a mechanism. I know what breaks it, what replaces it, and what a kirana owner actually needs versus what the market assumes he needs.
            </p>
            <p>
              The Feri Exchange Model didn't come from research. It came from seeing both sides of the same problem and being the first to connect them. That's not something you learn. That's something you're positioned for.
            </p>
          </div>

          <div className="md:w-[35%] flex flex-col gap-7">
            <div style={{ borderLeft: '3px solid #F59E0B', paddingLeft: '20px', paddingBottom: '16px', paddingTop: '16px' }}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: '44px', fontWeight: 800, color: '#0A0A0A' }}>
                17
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: '13px', color: '#6B7280', marginTop: '4px' }}>
                Building from where most founders never look
              </div>
            </div>
            <div style={{ borderLeft: '3px solid #F59E0B', paddingLeft: '20px', paddingBottom: '16px', paddingTop: '16px' }}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: '44px', fontWeight: 800, color: '#0A0A0A' }}>
                India
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: '13px', color: '#6B7280', marginTop: '4px' }}>
                Where the problem actually lives
              </div>
            </div>
            <div style={{ borderLeft: '3px solid #F59E0B', paddingLeft: '20px', paddingBottom: '16px', paddingTop: '16px' }}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: '44px', fontWeight: 800, color: '#0A0A0A' }}>
                YC
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: '13px', color: '#6B7280', marginTop: '4px' }}>
                Y Combinator applicant
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
