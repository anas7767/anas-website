import DotBackground from './components/DotBackground'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import WhyMe from './components/WhyMe'
import Insight from './components/Insight'
import Feri from './components/Feri'
import YCStrip from './components/YCStrip'
import Contact from './components/Contact'
import Footer from './components/Footer'

export default function App() {
  return (
    <div style={{ position: 'relative', background: '#FFFFFF' }}>
      <DotBackground />
      <div style={{ position: 'relative', zIndex: 1 }}>
        <Navbar />
        <Hero />
        <WhyMe />
        <Insight />
        <Feri />
        <YCStrip />
        <Contact />
        <Footer />
      </div>
    </div>
  )
}
